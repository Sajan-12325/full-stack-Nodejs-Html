var express = require('express');
var router = express.Router();


/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});

router.get('/entail', function(req, res, next) {
  res.send('respond with a detail');
});


//localhost:3000/users/

//localhost:3000/entail/

module.exports = router;
