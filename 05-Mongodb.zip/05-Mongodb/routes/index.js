const express = require('express');
const router = express.Router();
const { MongoClient } = require('mongodb');
const assert = require('assert');

const url = 'mongodb://localhost:27017/test';
const dbName = 'test';  // Define the database name
const client = new MongoClient(url);

async function connectToDatabase() {
  try {
    await client.connect();
    console.log("Connected to database");
  } catch (err) {
    console.error(err);
  }
}

// Calling the function to connect to database
connectToDatabase();


/* GET home page. */
router.get('/', (req, res, next) => {
  res.render('index');
});

router.get('/get-data', async (req, res, next) => {
  
  try {
    
    //Already connected to database on top.....

    const db = client.db(dbName);
    const collection = db.collection('user-data');

    const resultArray = await collection.find().toArray(); // Getting all documents as an array
    res.render('index', { items: resultArray });

  } catch (err) {
    console.error(err);
    res.status(500).send("Error fetching data" + err.message);
  } 
});

// Insert data

/*

router.post('/insert', function(req, res, next){
  var item = {
    title: req.body.title,
    content: req.body.content,
    author: req.body.author

  };
  mongo.connect(url, function(err, db){
    assert.equal(null, err);
    db.collection('user-data').insertOne(item, function(err, result){
      assert.equal(null, err);
      console.log('Item is inserted');
      db.close();
    });

  }
  );
}); */

router.post('/insert', async (req, res, next) => {
  console.log("Received data: ", req.body);
  // const client = new MongoClient(url);  already given on top
  try {
    if (!req.body.title || !req.body.content|| !req.body.author){
      res.status(400).send("Please Provide all fields..");
      return;
    }

    const db = client.db(dbName);
    const collection = db.collection('user-data');

    const item = {
      title: req.body.title,
      content: req.body.content,
      author: req.body.author,
      
    };

    const result = await collection.insertOne(item);
    console.log('Item inserted:', result.insertedId);
    
    res.redirect('/');  // Redirect to home page after insertion

  } catch (err) {
    console.error(err);
    res.status(500).send("Error inserting data" + err.message);
  } 
});

const {ObjectId} = require('mongodb');

router.post('/update', async (req, res, next)=>{
  try {
    if (!req.body.id || !req.body.title || !req.body.content|| !req.body.author){
      res.status(400).send("Please Provide all fields..");
      return;
    }
    const db = client.db(dbName);
    const collection = db.collection('user-data');

    

    const filter = { "_id": new ObjectId(req.body.id) };
    const update = { $set: { title: req.body.title, content: req.body.content, author: req.body.author }};

    

    const result = await collection.updateOne(filter, update);
    console.log('Item updated:', result.modifiedCount);

    res.redirect('/')  
  
  }
  catch (err){
    console.error(err);
    res.status(500).send("Error updating data: " + err.message);
  }

});

router.post('/delete', async (req, res, next) => {
  try {
    if (!req.body.id) {
      return res.status(400).send("Please provide an ID.");
    }

    const db = client.db(dbName);
    const collection = db.collection('user-data');

    const filter = { "_id": new ObjectId(req.body.id) };
    const result = await collection.deleteOne(filter);

    if (result.deletedCount === 0) {
      return res.status(404).send("No document found with this ID.");
    }

    console.log('Item deleted:', result.deletedCount);
    res.redirect('/');  // Redirect to home page after delete
  } 
  catch (err) {
    console.error(err);
    res.status(500).send("Error deleting data: " + err.message);
  }
});


module.exports = router;
